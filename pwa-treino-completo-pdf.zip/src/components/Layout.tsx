import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Home, Dumbbell, Apple, Play } from 'lucide-react';
import { useStore } from '../store';

export function Layout() {
  const activeWorkout = useStore((state) => state.activeWorkout);
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { to: '/', icon: Home, label: 'Início' },
    { to: '/workouts', icon: Dumbbell, label: 'Treinos' },
    { to: '/nutrition', icon: Apple, label: 'Dieta' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-zinc-950 text-zinc-50 pb-20">
      <main className="flex-1 overflow-y-auto px-4 py-6 max-w-md w-full mx-auto">
        <Outlet />
      </main>

      {/* Floating Active Workout Bar */}
      {activeWorkout && location.pathname !== '/active' && (
        <div 
          onClick={() => navigate('/active')}
          className="fixed bottom-20 left-4 right-4 bg-emerald-600 rounded-xl p-4 shadow-lg shadow-emerald-900/50 flex items-center justify-between cursor-pointer max-w-md mx-auto z-40 active:scale-95 transition-transform"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500 rounded-full animate-pulse">
              <Play size={20} fill="currentColor" />
            </div>
            <div>
              <p className="font-bold text-sm">Treino em Andamento</p>
              <p className="text-emerald-100 text-xs">{activeWorkout.name}</p>
            </div>
          </div>
          <div className="text-emerald-100 text-xs font-semibold uppercase tracking-wider">
            Retomar
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 pb-safe pt-2 px-6 z-50">
        <div className="flex justify-between items-center max-w-md mx-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex flex-col items-center p-2 rounded-xl transition-colors ${
                  isActive ? 'text-emerald-500' : 'text-zinc-500 hover:text-zinc-300'
                }`
              }
            >
              <item.icon size={24} strokeWidth={2.5} />
              <span className="text-[10px] mt-1 font-medium">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
