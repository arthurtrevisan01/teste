import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { format } from 'date-fns';

export interface ExerciseSet {
  id: string;
  reps: number;
  weight: number;
  completed: boolean;
}

export interface ExerciseData {
  id: string;
  name: string;
  muscleGroup: string;
}

export interface WorkoutExercise {
  id: string;
  exercise: ExerciseData;
  sets: ExerciseSet[];
  notes?: string;
}

export interface WorkoutTemplate {
  id: string;
  name: string;
  description: string;
  exercises: WorkoutExercise[];
}

export interface NutritionGoal {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface NutritionLog {
  date: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface AppState {
  // Data
  templates: WorkoutTemplate[];
  customExercises: ExerciseData[];
  nutritionGoal: NutritionGoal;
  nutritionLogs: NutritionLog[];
  activeWorkout: WorkoutTemplate | null;
  workoutHistory: { date: string; workout: WorkoutTemplate }[];
  
  // Actions
  addTemplate: (template: WorkoutTemplate) => void;
  updateTemplate: (id: string, template: WorkoutTemplate) => void;
  deleteTemplate: (id: string) => void;
  
  startWorkout: (template: WorkoutTemplate) => void;
  updateActiveSet: (exerciseId: string, setId: string, updates: Partial<ExerciseSet>) => void;
  finishActiveWorkout: () => void;
  cancelActiveWorkout: () => void;
  
  updateNutritionGoal: (goal: NutritionGoal) => void;
  logNutrition: (log: Partial<NutritionLog>) => void;
  
  addCustomExercise: (exercise: ExerciseData) => void;
  openAiKey: string | null;
  setOpenAiKey: (key: string | null) => void;
}

const DEFAULT_EXERCISES: ExerciseData[] = [
  // Peito
  { id: '1', name: 'Supino Reto', muscleGroup: 'Peito' },
  { id: '1b', name: 'Supino Inclinado', muscleGroup: 'Peito' },
  { id: '1c', name: 'Crucifixo', muscleGroup: 'Peito' },
  { id: '1d', name: 'Crossover', muscleGroup: 'Peito' },
  // Pernas
  { id: '2', name: 'Agachamento Livre', muscleGroup: 'Pernas' },
  { id: '2b', name: 'Leg Press', muscleGroup: 'Pernas' },
  { id: '2c', name: 'Cadeira Extensora', muscleGroup: 'Pernas' },
  { id: '2d', name: 'Cadeira Flexora', muscleGroup: 'Pernas' },
  { id: '2e', name: 'Panturrilha em Pé', muscleGroup: 'Pernas' },
  // Costas
  { id: '3', name: 'Levantamento Terra', muscleGroup: 'Costas' },
  { id: '3b', name: 'Puxada Frontal', muscleGroup: 'Costas' },
  { id: '3c', name: 'Remada Curvada', muscleGroup: 'Costas' },
  { id: '3d', name: 'Remada Baixa', muscleGroup: 'Costas' },
  // Ombros
  { id: '4', name: 'Desenvolvimento', muscleGroup: 'Ombros' },
  { id: '4b', name: 'Elevação Lateral', muscleGroup: 'Ombros' },
  { id: '4c', name: 'Elevação Frontal', muscleGroup: 'Ombros' },
  // Bíceps
  { id: '5', name: 'Rosca Direta', muscleGroup: 'Bíceps' },
  { id: '5b', name: 'Rosca Alternada', muscleGroup: 'Bíceps' },
  { id: '5c', name: 'Rosca Martelo', muscleGroup: 'Bíceps' },
  // Tríceps
  { id: '6', name: 'Tríceps Testa', muscleGroup: 'Tríceps' },
  { id: '6b', name: 'Tríceps Pulley', muscleGroup: 'Tríceps' },
  { id: '6c', name: 'Tríceps Corda', muscleGroup: 'Tríceps' },
  // Core
  { id: '7', name: 'Prancha', muscleGroup: 'Core' },
  { id: '7b', name: 'Abdominal Supra', muscleGroup: 'Core' },
];

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      templates: [
        {
          id: 't1',
          name: 'Treino A - Peito e Tríceps',
          description: 'Foco em hipertrofia',
          exercises: [
            {
              id: 'e1',
              exercise: DEFAULT_EXERCISES[0],
              sets: [
                { id: 's1', reps: 10, weight: 60, completed: false },
                { id: 's2', reps: 10, weight: 60, completed: false },
                { id: 's3', reps: 8, weight: 65, completed: false },
              ]
            }
          ]
        }
      ],
      customExercises: DEFAULT_EXERCISES,
      nutritionGoal: { calories: 2500, protein: 180, carbs: 250, fat: 70 },
      nutritionLogs: [],
      activeWorkout: null,
      workoutHistory: [],

      addTemplate: (template) => set((state) => ({ templates: [...state.templates, template] })),
      updateTemplate: (id, template) => set((state) => ({
        templates: state.templates.map((t) => (t.id === id ? template : t))
      })),
      deleteTemplate: (id) => set((state) => ({
        templates: state.templates.filter((t) => t.id !== id)
      })),

      startWorkout: (template) => {
        // Create a deep copy for the active workout to avoid mutating the template directly
        const activeWorkout = JSON.parse(JSON.stringify(template));
        set({ activeWorkout });
      },
      updateActiveSet: (exerciseId, setId, updates) => set((state) => {
        if (!state.activeWorkout) return state;
        const newWorkout = { ...state.activeWorkout };
        const exercise = newWorkout.exercises.find(e => e.id === exerciseId);
        if (exercise) {
          const setIndex = exercise.sets.findIndex(s => s.id === setId);
          if (setIndex !== -1) {
            exercise.sets[setIndex] = { ...exercise.sets[setIndex], ...updates };
          }
        }
        return { activeWorkout: newWorkout };
      }),
      finishActiveWorkout: () => set((state) => {
        if (!state.activeWorkout) return state;
        const date = format(new Date(), 'yyyy-MM-dd');
        return {
          workoutHistory: [...state.workoutHistory, { date, workout: state.activeWorkout }],
          activeWorkout: null
        };
      }),
      cancelActiveWorkout: () => set({ activeWorkout: null }),

      updateNutritionGoal: (goal) => set({ nutritionGoal: goal }),
      logNutrition: (log) => set((state) => {
        const date = format(new Date(), 'yyyy-MM-dd');
        const existingLogIndex = state.nutritionLogs.findIndex(l => l.date === date);
        const newLogs = [...state.nutritionLogs];
        
        if (existingLogIndex >= 0) {
          newLogs[existingLogIndex] = { ...newLogs[existingLogIndex], ...log };
        } else {
          newLogs.push({
            date,
            calories: log.calories || 0,
            protein: log.protein || 0,
            carbs: log.carbs || 0,
            fat: log.fat || 0
          });
        }
        return { nutritionLogs: newLogs };
      }),

      addCustomExercise: (exercise) => set((state) => ({
        customExercises: [...state.customExercises, exercise]
      })),
      openAiKey: null,
      setOpenAiKey: (key) => set({ openAiKey: key })
    }),
    {
      name: 'titanfit-storage'
    }
  )
);
