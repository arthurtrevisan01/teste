import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Play, TrendingUp, Zap, Target } from 'lucide-react';
import { useStore } from '../store';
import { useNavigate } from 'react-router-dom';

export function Dashboard() {
  const navigate = useNavigate();
  const { templates, nutritionGoal, nutritionLogs, activeWorkout, startWorkout } = useStore();
  
  const todayDate = format(new Date(), 'yyyy-MM-dd');
  const todayLog = nutritionLogs.find(l => l.date === todayDate) || {
    calories: 0, protein: 0, carbs: 0, fat: 0
  };

  const calPerc = Math.min((todayLog.calories / nutritionGoal.calories) * 100, 100);

  const handleQuickStart = () => {
    if (activeWorkout) {
      navigate('/active');
    } else if (templates.length > 0) {
      startWorkout(templates[0]);
      navigate('/active');
    } else {
      navigate('/workouts');
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <p className="text-zinc-400 text-sm font-medium uppercase tracking-wider">
            {format(new Date(), "EEEE, d 'de' MMMM", { locale: ptBR })}
          </p>
          <h1 className="text-3xl font-extrabold text-zinc-50 tracking-tight mt-1">
            Olá, Titan!
          </h1>
        </div>
        <div className="w-12 h-12 bg-zinc-800 rounded-full flex items-center justify-center border-2 border-emerald-500 overflow-hidden shadow-lg shadow-emerald-900/30">
          <Zap className="text-emerald-400" size={24} fill="currentColor" />
        </div>
      </div>

      {/* Quick Start Card */}
      <div className="bg-gradient-to-br from-emerald-600 to-emerald-900 rounded-3xl p-6 shadow-xl shadow-emerald-900/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <TrendingUp size={120} strokeWidth={3} />
        </div>
        <div className="relative z-10">
          <h2 className="text-xl font-bold text-white mb-2">Próximo Treino</h2>
          <p className="text-emerald-100 font-medium mb-6 opacity-90 line-clamp-1">
            {activeWorkout ? activeWorkout.name : (templates[0]?.name || 'Nenhum treino montado')}
          </p>
          <button
            onClick={handleQuickStart}
            className="bg-white text-emerald-950 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg active:scale-95 transition-transform"
          >
            <Play size={20} fill="currentColor" />
            {activeWorkout ? 'Retomar Treino' : 'Iniciar Treino'}
          </button>
        </div>
      </div>

      {/* Nutrition Summary */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Target className="text-emerald-500" size={20} />
            Metas Nutricionais
          </h2>
          <button onClick={() => navigate('/nutrition')} className="text-zinc-400 text-sm hover:text-white transition-colors">
            Detalhes
          </button>
        </div>

        <div className="flex items-center gap-6 mb-6">
          {/* Circular Progress */}
          <div className="relative w-24 h-24 flex-shrink-0">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-zinc-800"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="text-emerald-500 transition-all duration-1000 ease-out"
                strokeDasharray={`${calPerc}, 100`}
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="4"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-xl font-bold leading-none">{todayLog.calories}</span>
              <span className="text-[10px] text-zinc-400 font-medium">kcal</span>
            </div>
          </div>

          <div className="flex-1 space-y-4">
            <MacroBar label="Proteína" current={todayLog.protein} total={nutritionGoal.protein} color="bg-blue-500" />
            <MacroBar label="Carboidrato" current={todayLog.carbs} total={nutritionGoal.carbs} color="bg-amber-500" />
            <MacroBar label="Gordura" current={todayLog.fat} total={nutritionGoal.fat} color="bg-rose-500" />
          </div>
        </div>
      </div>
    </div>
  );
}

function MacroBar({ label, current, total, color }: { label: string, current: number, total: number, color: string }) {
  const percentage = Math.min((current / total) * 100, 100);
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-zinc-400 font-medium">{label}</span>
        <span className="text-zinc-300 font-bold">{current} / {total}g</span>
      </div>
      <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
