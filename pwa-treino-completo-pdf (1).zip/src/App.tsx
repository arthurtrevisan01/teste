import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Workouts } from './pages/Workouts';
import { ActiveWorkout } from './pages/ActiveWorkout';
import { Nutrition } from './pages/Nutrition';

export function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="workouts" element={<Workouts />} />
          <Route path="nutrition" element={<Nutrition />} />
        </Route>
        {/* Active workout is fullscreen without standard bottom nav */}
        <Route path="/active" element={<ActiveWorkout />} />
      </Routes>
    </Router>
  );
}
