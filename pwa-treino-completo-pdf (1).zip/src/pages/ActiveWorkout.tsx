import { useState, useEffect } from 'react';
import { useStore, WorkoutExercise, ExerciseSet } from '../store';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, ChevronLeft, Save } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Helper for conditional classes
function cn(...classes: (string | undefined | null | false)[]) {
  return twMerge(clsx(classes));
}

export function ActiveWorkout() {
  const { activeWorkout, updateActiveSet, finishActiveWorkout, cancelActiveWorkout } = useStore();
  const navigate = useNavigate();
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    if (!activeWorkout) {
      navigate('/');
      return;
    }
    const interval = setInterval(() => setTimer(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, [activeWorkout, navigate]);

  if (!activeWorkout) return null;

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleFinish = () => {
    finishActiveWorkout();
    navigate('/');
  };

  const handleCancel = () => {
    if (confirm('Deseja realmente cancelar este treino? Nenhum progresso será salvo.')) {
      cancelActiveWorkout();
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 flex flex-col pb-safe max-w-md mx-auto relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-[-20%] left-[-20%] w-[140%] h-[40%] bg-emerald-900/20 blur-3xl rounded-full pointer-events-none" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-zinc-950/80 backdrop-blur-xl border-b border-zinc-800 p-4 flex justify-between items-center shadow-lg shadow-zinc-950">
        <button onClick={handleCancel} className="p-2 text-zinc-400 hover:text-rose-500 hover:bg-zinc-900 rounded-full transition-colors">
          <ChevronLeft size={24} />
        </button>
        <div className="text-center flex-1">
          <h1 className="text-lg font-bold truncate px-4">{activeWorkout.name}</h1>
          <p className="text-emerald-400 font-mono font-medium">{formatTime(timer)}</p>
        </div>
        <button onClick={handleFinish} className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-lg shadow-emerald-900/50 transition-all active:scale-95 flex items-center gap-2">
          <Save size={16} /> Finalizar
        </button>
      </header>

      {/* Exercises List */}
      <main className="flex-1 overflow-y-auto p-4 space-y-6">
        {activeWorkout.exercises.map((exercise, index) => (
          <ExerciseCard 
            key={exercise.id} 
            exercise={exercise} 
            index={index} 
            updateSet={(setId, updates) => updateActiveSet(exercise.id, setId, updates)} 
          />
        ))}

        <div className="pt-6 pb-8">
          <button 
            onClick={handleFinish}
            className="w-full bg-zinc-50 text-zinc-950 py-4 rounded-2xl font-extrabold text-lg flex items-center justify-center gap-2 shadow-xl shadow-zinc-900 active:scale-95 transition-all"
          >
            Concluir Treino
          </button>
        </div>
      </main>
    </div>
  );
}

function ExerciseCard({ 
  exercise, 
  index,
  updateSet 
}: { 
  exercise: WorkoutExercise; 
  index: number;
  updateSet: (setId: string, updates: Partial<ExerciseSet>) => void;
}) {
  return (
    <div className="bg-zinc-900/80 backdrop-blur-md border border-zinc-800/50 rounded-3xl overflow-hidden shadow-xl">
      <div className="p-4 bg-zinc-900 border-b border-zinc-800/50 flex justify-between items-center">
        <div>
          <span className="text-emerald-500 font-bold text-sm tracking-wider uppercase mb-1 block">
            Exercício {index + 1}
          </span>
          <h2 className="text-lg font-bold text-zinc-50">{exercise.exercise.name}</h2>
          <p className="text-zinc-500 text-sm">{exercise.exercise.muscleGroup}</p>
        </div>
      </div>

      <div className="p-2">
        {/* Table Header */}
        <div className="grid grid-cols-4 gap-2 px-3 py-2 text-xs font-semibold text-zinc-500 uppercase tracking-wider text-center">
          <div>Série</div>
          <div>Kg</div>
          <div>Reps</div>
          <div>Feito</div>
        </div>

        {/* Sets */}
        <div className="space-y-2">
          {exercise.sets.map((set, idx) => (
            <div 
              key={set.id} 
              className={cn(
                "grid grid-cols-4 gap-2 px-3 py-3 rounded-xl items-center text-center transition-all",
                set.completed ? "bg-emerald-900/20 border border-emerald-900/50" : "bg-zinc-800/30"
              )}
            >
              <div className="text-zinc-400 font-bold bg-zinc-900 rounded-lg py-1">
                {idx + 1}
              </div>
              
              <div className="relative">
                <input 
                  type="number" 
                  value={set.weight || ''} 
                  onChange={(e) => updateSet(set.id, { weight: Number(e.target.value) })}
                  className={cn(
                    "w-full bg-zinc-900 rounded-lg py-2 text-center text-sm font-bold border focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors",
                    set.completed ? "border-transparent text-zinc-300" : "border-zinc-700 text-zinc-50"
                  )}
                  placeholder="-"
                  disabled={set.completed}
                />
              </div>

              <div className="relative">
                <input 
                  type="number" 
                  value={set.reps || ''} 
                  onChange={(e) => updateSet(set.id, { reps: Number(e.target.value) })}
                  className={cn(
                    "w-full bg-zinc-900 rounded-lg py-2 text-center text-sm font-bold border focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors",
                    set.completed ? "border-transparent text-zinc-300" : "border-zinc-700 text-zinc-50"
                  )}
                  placeholder="-"
                  disabled={set.completed}
                />
              </div>

              <button 
                onClick={() => updateSet(set.id, { completed: !set.completed })}
                className={cn(
                  "mx-auto w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90 shadow-md",
                  set.completed 
                    ? "bg-emerald-500 text-zinc-950 shadow-emerald-500/20" 
                    : "bg-zinc-800 text-zinc-500 hover:bg-zinc-700 hover:text-zinc-300 shadow-none"
                )}
              >
                <CheckCircle2 size={20} className={set.completed ? "fill-emerald-400" : ""} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
