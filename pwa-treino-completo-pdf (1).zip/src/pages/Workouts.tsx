import { useState, useRef } from 'react';
import { useStore, WorkoutTemplate, WorkoutExercise } from '../store';
import { Play, Download, Plus, MoreVertical, X, Check, Trash2, Bot, LayoutTemplate } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export function Workouts() {
  const { templates, customExercises, startWorkout, addTemplate, updateTemplate, deleteTemplate } = useStore();
  const navigate = useNavigate();
  const pdfRef = useRef<HTMLDivElement>(null);
  
  const [exporting, setExporting] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<WorkoutTemplate | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  
  const [isAutoGenerating, setIsAutoGenerating] = useState(false);
  const [autoForm, setAutoForm] = useState({
    splitType: 'abc', // abc, upper_lower, full_body, bro_split
    goal: 'Hipertrofia'
  });

  const handleStart = (t: WorkoutTemplate) => {
    startWorkout(t);
    navigate('/active');
  };

  const handleAutoGenerate = () => {
    const { splitType, goal } = autoForm;
    
    const getExs = (group: string, count: number) => {
      let filtered = customExercises.filter(e => e.muscleGroup === group);
      if (filtered.length === 0) filtered = customExercises.filter(e => e.muscleGroup.includes(group));
      if (filtered.length === 0) return [];
      
      const shuffled = [...filtered].sort(() => 0.5 - Math.random());
      return shuffled.slice(0, Math.min(count, shuffled.length));
    };

    const createWorkoutExs = (exercises: any[]): WorkoutExercise[] => {
      const reps = goal === 'Força' ? 5 : goal === 'Resistência' ? 15 : 10;
      const setsCount = goal === 'Força' ? 4 : 3;
      
      return exercises.map((ex, i) => ({
        id: Date.now().toString() + i + Math.random(),
        exercise: ex,
        sets: Array(setsCount).fill(null).map((_, j) => ({
          id: Date.now().toString() + 's' + i + j + Math.random(),
          reps: reps,
          weight: 0,
          completed: false
        }))
      }));
    };

    let generatedTemplates: WorkoutTemplate[] = [];

    if (splitType === 'full_body') {
      // Full Body A, B, C
      for(let i=1; i<=3; i++) {
        const exs = [
          ...getExs('Pernas', 2),
          ...getExs('Peito', 1),
          ...getExs('Costas', 1),
          ...getExs('Ombros', 1),
          ...getExs('Bíceps', 1),
          ...getExs('Tríceps', 1)
        ];
        generatedTemplates.push({
          id: Date.now().toString() + 't' + i,
          name: `Treino ${String.fromCharCode(64+i)} - Full Body`,
          description: `Corpo Todo - Foco em ${goal}`,
          exercises: createWorkoutExs(exs)
        });
      }
    } else if (splitType === 'upper_lower') {
      // Upper / Lower (A e B) x 2
      const splits = [
        { name: 'A - Superiores (Upper)', groups: [{g:'Peito',c:2}, {g:'Costas',c:2}, {g:'Ombros',c:1}, {g:'Bíceps',c:1}, {g:'Tríceps',c:1}] },
        { name: 'B - Inferiores (Lower)', groups: [{g:'Pernas',c:5}, {g:'Core',c:2}] },
      ];
      
      splits.forEach((split, i) => {
        let exs: any[] = [];
        split.groups.forEach(groupDef => exs.push(...getExs(groupDef.g, groupDef.c)));
        
        generatedTemplates.push({
          id: Date.now().toString() + 't' + i,
          name: `Treino ${split.name[0]} - ${split.name.split(' - ')[1]}`,
          description: `Periodização Upper/Lower - ${goal}`,
          exercises: createWorkoutExs(exs)
        });
      });
    } else if (splitType === 'abc') {
      // Push / Pull / Legs
      const splits = [
        { name: 'Treino A (Push)', desc: 'Peito, Ombro e Tríceps', groups: [{ g: 'Peito', c: 3 }, { g: 'Ombros', c: 2 }, { g: 'Tríceps', c: 2 }] },
        { name: 'Treino B (Pull)', desc: 'Costas, Bíceps e Core', groups: [{ g: 'Costas', c: 3 }, { g: 'Bíceps', c: 2 }, { g: 'Core', c: 2 }] },
        { name: 'Treino C (Legs)', desc: 'Membros Inferiores Completos', groups: [{ g: 'Pernas', c: 6 }, { g: 'Core', c: 1 }] },
      ];
      
      splits.forEach((split, i) => {
        let exs: any[] = [];
        split.groups.forEach(groupDef => exs.push(...getExs(groupDef.g, groupDef.c)));
        
        generatedTemplates.push({
          id: Date.now().toString() + 't' + i,
          name: split.name,
          description: split.desc,
          exercises: createWorkoutExs(exs)
        });
      });
    } else if (splitType === 'bro_split') {
      // Bro Split (Um grupo muscular por dia)
      const splits = [
        { name: 'Treino A - Peito', groups: [{ g: 'Peito', c: 5 }, { g: 'Core', c: 2 }] },
        { name: 'Treino B - Costas', groups: [{ g: 'Costas', c: 5 }] },
        { name: 'Treino C - Pernas', groups: [{ g: 'Pernas', c: 6 }] },
        { name: 'Treino D - Ombros', groups: [{ g: 'Ombros', c: 4 }, { g: 'Core', c: 2 }] },
        { name: 'Treino E - Braços', groups: [{ g: 'Bíceps', c: 3 }, { g: 'Tríceps', c: 3 }] },
      ];
      
      splits.forEach((split, i) => {
        let exs: any[] = [];
        split.groups.forEach(groupDef => exs.push(...getExs(groupDef.g, groupDef.c)));
        
        generatedTemplates.push({
          id: Date.now().toString() + 't' + i,
          name: split.name,
          description: `Bro Split (${goal})`,
          exercises: createWorkoutExs(exs)
        });
      });
    }

    generatedTemplates.forEach(t => addTemplate(t));
    setIsAutoGenerating(false);
  };

  const handleExportPDF = async () => {
    if (!pdfRef.current) return;
    setExporting(true);
    
    try {
      const element = pdfRef.current;
      element.style.display = 'block';
      
      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: '#ffffff',
        useCORS: true,
      });
      
      element.style.display = 'none';

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('Planilha_TitanFit_Pro.pdf');
    } catch (error) {
      console.error('Erro ao gerar PDF', error);
      alert('Houve um erro ao gerar o PDF. Tente novamente.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex justify-between items-end mb-8 bg-gradient-to-r from-zinc-900 to-zinc-950 p-6 -mx-4 -mt-6 rounded-b-[3rem] shadow-2xl border-b border-zinc-800">
        <div>
          <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-500 tracking-tight">Treinos PRO</h1>
          <p className="text-zinc-400 mt-1 font-medium text-sm">Organize suas rotinas</p>
        </div>
        <button 
          onClick={handleExportPDF}
          disabled={exporting}
          className="bg-emerald-500/10 text-emerald-500 p-4 rounded-3xl flex items-center justify-center border border-emerald-500/20 active:scale-95 transition-all shadow-lg backdrop-blur-md"
        >
          <Download size={28} className={exporting ? 'animate-bounce' : ''} />
        </button>
      </div>

      <div className="grid gap-4">
        {templates.map(t => (
          <div key={t.id} className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-xl transition-all relative overflow-hidden group">
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none group-hover:bg-emerald-500/10 transition-colors" />
            
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div>
                <h2 className="text-xl font-bold text-zinc-50">{t.name}</h2>
                <p className="text-zinc-400 text-sm mt-1">{t.description || `${t.exercises.length} exercícios`}</p>
              </div>
              <button 
                onClick={() => {
                  setEditingTemplate(t);
                  setIsCreating(false);
                }}
                className="text-zinc-500 hover:text-white p-2 bg-zinc-800/50 rounded-full transition-colors active:scale-90 shadow-md backdrop-blur-sm"
              >
                <MoreVertical size={20} />
              </button>
            </div>
            
            <div className="flex gap-3 mt-6 relative z-10">
              <button
                onClick={() => handleStart(t)}
                className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-900/20 active:scale-95 text-lg"
              >
                <Play size={20} fill="currentColor" /> Iniciar Treino
              </button>
            </div>
          </div>
        ))}

        <div className="flex gap-4 mt-2">
          <button 
            onClick={() => {
              setEditingTemplate({
                id: Date.now().toString(),
                name: 'Novo Treino',
                description: '',
                exercises: []
              });
              setIsCreating(true);
            }}
            className="flex-1 border border-dashed border-zinc-700 bg-zinc-900/50 text-zinc-400 hover:text-white hover:border-zinc-500 transition-all rounded-[2rem] p-6 flex flex-col items-center justify-center gap-3 font-semibold active:scale-95 shadow-inner"
          >
            <Plus size={28} strokeWidth={2.5} />
            <span className="text-xs uppercase tracking-wider">Criar Manual</span>
          </button>
          
          <button 
            onClick={() => setIsAutoGenerating(true)}
            className="flex-1 border border-emerald-900/50 bg-emerald-900/10 text-emerald-500 hover:text-emerald-400 hover:border-emerald-700 transition-all rounded-[2rem] p-6 flex flex-col items-center justify-center gap-3 font-semibold active:scale-95 shadow-inner"
          >
            <Bot size={28} strokeWidth={2.5} />
            <span className="text-xs uppercase tracking-wider">IA Geradora</span>
          </button>
        </div>
      </div>

      {/* Auto Generator Modal PRO */}
      {isAutoGenerating && (
        <div className="fixed inset-0 z-50 bg-zinc-950/95 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-2xl w-full max-w-sm space-y-6 relative">
            <button 
              onClick={() => setIsAutoGenerating(false)}
              className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white bg-zinc-800/50 rounded-full shadow-md backdrop-blur-sm"
            >
              <X size={20} />
            </button>
            
            <div className="text-center pt-2">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/30 shadow-lg shadow-emerald-500/10">
                <LayoutTemplate size={36} className="text-emerald-500" />
              </div>
              <h2 className="text-2xl font-bold text-zinc-50 tracking-tight">Gerador de Treinos</h2>
              <p className="text-zinc-400 text-xs mt-2 px-4">Monte uma periodização inteligente</p>
            </div>

            <div className="space-y-4">
              <div className="bg-zinc-950/50 p-3 rounded-2xl border border-zinc-800">
                <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mb-1 block">Divisão do Treino (Split)</label>
                <select 
                  value={autoForm.splitType}
                  onChange={e => setAutoForm({...autoForm, splitType: e.target.value})}
                  className="w-full bg-transparent text-sm font-bold text-zinc-50 focus:outline-none mt-1 [&>option]:text-zinc-900"
                >
                  <option value="abc">ABC (Push / Pull / Legs)</option>
                  <option value="upper_lower">Upper / Lower (Superiores / Inferiores)</option>
                  <option value="full_body">Full Body (Corpo Inteiro - 3 dias)</option>
                  <option value="bro_split">Bro Split (1 Músculo por Dia - 5 dias)</option>
                </select>
              </div>
              
              <div className="bg-zinc-950/50 p-3 rounded-2xl border border-zinc-800">
                <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mb-1 block">Objetivo</label>
                <select 
                  value={autoForm.goal}
                  onChange={e => setAutoForm({...autoForm, goal: e.target.value})}
                  className="w-full bg-transparent text-sm font-bold text-zinc-50 focus:outline-none mt-1 [&>option]:text-zinc-900"
                >
                  <option value="Hipertrofia">Hipertrofia Muscular (8-12 reps)</option>
                  <option value="Força">Força Máxima (3-5 reps)</option>
                  <option value="Resistência">Resistência (15-20 reps)</option>
                </select>
              </div>
              
              <div className="bg-emerald-900/10 border border-emerald-900/20 p-4 rounded-xl">
                <p className="text-xs text-emerald-200/70 leading-relaxed font-medium">
                  A IA agrupará os exercícios de forma biomecanicamente correta baseada no split escolhido. Todas as planilhas ficarão prontas para download em PDF.
                </p>
              </div>
            </div>

            <button 
              onClick={handleAutoGenerate}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-500/25 active:scale-95 transition-transform text-lg"
            >
              Criar Planilhas PRO
            </button>
          </div>
        </div>
      )}

      {/* Editor Modal PRO */}
      {editingTemplate && (
        <div className="fixed inset-0 z-50 bg-zinc-950/95 backdrop-blur-xl flex flex-col p-4 overflow-y-auto pb-24">
          <div className="flex justify-between items-center mb-8 pt-6">
            <button onClick={() => setEditingTemplate(null)} className="p-3 text-zinc-400 hover:text-white bg-zinc-900 rounded-full shadow-lg border border-zinc-800">
              <X size={24} />
            </button>
            <h2 className="text-xl font-bold text-zinc-50">{isCreating ? 'Montar Treino' : 'Editar Rotina'}</h2>
            <button 
              onClick={() => {
                if (isCreating) addTemplate(editingTemplate);
                else updateTemplate(editingTemplate.id, editingTemplate);
                setEditingTemplate(null);
              }} 
              className="p-3 text-emerald-500 hover:text-white bg-emerald-900/30 border border-emerald-900 rounded-full shadow-lg"
            >
              <Check size={24} />
            </button>
          </div>

          <div className="space-y-4 mb-8">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-inner">
              <input 
                type="text" 
                value={editingTemplate.name} 
                onChange={e => setEditingTemplate({...editingTemplate, name: e.target.value})}
                className="w-full bg-transparent text-xl font-bold text-zinc-50 focus:outline-none placeholder:text-zinc-600 mb-2"
                placeholder="Ex: Treino A - Costas e Bíceps"
              />
              <div className="h-px bg-zinc-800 w-full mb-2" />
              <input 
                type="text" 
                value={editingTemplate.description} 
                onChange={e => setEditingTemplate({...editingTemplate, description: e.target.value})}
                className="w-full bg-transparent text-sm text-zinc-400 focus:outline-none placeholder:text-zinc-600"
                placeholder="Objetivo principal deste treino..."
              />
            </div>
          </div>

          <div className="mb-6 flex-1">
            <h3 className="text-zinc-500 font-bold uppercase tracking-wider text-[10px] mb-3 ml-2">Exercícios Inclusos</h3>
            <div className="space-y-3">
              {editingTemplate.exercises.map((ex) => (
                <div key={ex.id} className="bg-zinc-900 border border-zinc-800 rounded-[1.5rem] p-4 flex justify-between items-center shadow-lg relative overflow-hidden">
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500" />
                  <div className="pl-2">
                    <span className="text-emerald-500 font-bold text-[10px] uppercase tracking-wider block mb-0.5">Músculo: {ex.exercise.muscleGroup}</span>
                    <p className="font-bold text-zinc-50 text-lg">{ex.exercise.name}</p>
                    <p className="text-zinc-500 text-xs font-semibold mt-1 bg-zinc-950 inline-block px-2 py-0.5 rounded-md">{ex.sets.length} séries</p>
                  </div>
                  <button 
                    onClick={() => {
                      const newExs = editingTemplate.exercises.filter(e => e.id !== ex.id);
                      setEditingTemplate({...editingTemplate, exercises: newExs});
                    }}
                    className="p-3 text-rose-500 hover:bg-zinc-800 rounded-full transition-colors active:scale-90"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              ))}
              
              {editingTemplate.exercises.length === 0 && (
                <div className="text-center p-8 border-2 border-dashed border-zinc-800 rounded-[2rem]">
                  <p className="text-zinc-500 font-medium text-sm">Nenhum exercício adicionado ainda.</p>
                </div>
              )}
            </div>

            <div className="mt-6 bg-zinc-900/50 border border-zinc-800/50 rounded-[2rem] p-5">
              <p className="text-xs text-zinc-400 font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
                <Plus size={14} className="text-emerald-500"/> Adicionar Movimento
              </p>
              <select 
                onChange={(e) => {
                  if (!e.target.value) return;
                  const selectedEx = customExercises.find(c => c.id === e.target.value);
                  if (!selectedEx) return;
                  
                  const newExercise: WorkoutExercise = {
                    id: Date.now().toString(),
                    exercise: selectedEx,
                    sets: [
                      { id: Date.now().toString() + '1', reps: 10, weight: 0, completed: false },
                      { id: Date.now().toString() + '2', reps: 10, weight: 0, completed: false },
                      { id: Date.now().toString() + '3', reps: 10, weight: 0, completed: false }
                    ]
                  };
                  
                  setEditingTemplate({
                    ...editingTemplate, 
                    exercises: [...editingTemplate.exercises, newExercise]
                  });
                  e.target.value = '';
                }}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-zinc-50 focus:outline-none focus:border-emerald-500 font-medium text-sm [&>option]:text-zinc-900"
                defaultValue=""
              >
                <option value="" disabled>Selecione da biblioteca...</option>
                {customExercises.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.muscleGroup})</option>
                ))}
              </select>
            </div>
          </div>
          
          {!isCreating && (
            <button 
              onClick={() => {
                if (confirm('Deletar esta planilha de treino permanentemente?')) {
                  deleteTemplate(editingTemplate.id);
                  setEditingTemplate(null);
                }
              }}
              className="mt-8 mb-4 w-full bg-rose-500/10 text-rose-500 py-4 rounded-2xl font-bold border border-rose-500/20 active:scale-95 transition-transform"
            >
              Apagar Planilha Inteira
            </button>
          )}
        </div>
      )}

      {/* Hidden Div for PDF Export */}
      <div ref={pdfRef} style={{ display: 'none', padding: '40px', width: '800px', backgroundColor: '#ffffff', color: '#000000', fontFamily: 'sans-serif' }}>
        <div style={{ borderBottom: '4px solid #10b981', paddingBottom: '20px', marginBottom: '30px', textAlign: 'center' }}>
          <h1 style={{ fontSize: '32px', margin: '0', color: '#09090b', textTransform: 'uppercase', letterSpacing: '2px', fontWeight: '900' }}>TitanFit PRO</h1>
          <p style={{ color: '#52525b', marginTop: '10px', fontSize: '16px', fontWeight: 'bold' }}>Planilha de Treino de Alta Performance - {new Date().toLocaleDateString('pt-BR')}</p>
        </div>

        {templates.map((t) => (
          <div key={`pdf-${t.id}`} style={{ marginBottom: '40px', backgroundColor: '#f8fafc', borderRadius: '16px', padding: '24px', border: '1px solid #e2e8f0' }}>
            <h2 style={{ fontSize: '24px', margin: '0 0 8px 0', color: '#0f172a', borderBottom: '2px solid #e2e8f0', paddingBottom: '12px', fontWeight: '800' }}>
              {t.name}
            </h2>
            <p style={{ color: '#64748b', fontStyle: 'italic', marginBottom: '20px', fontSize: '14px' }}>{t.description}</p>
            
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#10b981', color: '#ffffff', textAlign: 'left', fontSize: '14px', textTransform: 'uppercase' }}>
                  <th style={{ padding: '12px', borderRadius: '8px 0 0 8px' }}>Exercício (Músculo)</th>
                  <th style={{ padding: '12px' }}>Séries x Reps</th>
                  <th style={{ padding: '12px', borderRadius: '0 8px 8px 0' }}>Carga de Referência</th>
                </tr>
              </thead>
              <tbody>
                {t.exercises.map((ex, idx) => (
                  <tr key={`pdf-ex-${ex.id}`} style={{ borderBottom: idx !== t.exercises.length - 1 ? '1px solid #e2e8f0' : 'none' }}>
                    <td style={{ padding: '16px 12px', fontWeight: 'bold', color: '#1e293b' }}>
                      {ex.exercise.name}
                      <span style={{ display: 'block', fontSize: '12px', color: '#94a3b8', fontWeight: 'normal', marginTop: '4px' }}>Foco: {ex.exercise.muscleGroup}</span>
                    </td>
                    <td style={{ padding: '16px 12px', color: '#475569', fontWeight: 'bold' }}>
                      {ex.sets.length} séries x {ex.sets[0]?.reps || 0}
                    </td>
                    <td style={{ padding: '16px 12px', color: '#475569' }}>
                      {ex.sets[0]?.weight ? `${ex.sets[0].weight} kg` : '- kg'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
        
        <div style={{ marginTop: '40px', textAlign: 'center', color: '#94a3b8', fontSize: '14px', fontWeight: 'bold', borderTop: '1px solid #e2e8f0', paddingTop: '20px' }}>
          Gerado pelo Aplicativo TitanFit PRO - Nunca pare de treinar.
        </div>
      </div>
    </div>
  );
}
